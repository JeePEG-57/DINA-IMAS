package eu.itm.pcsdialog;

import org.zeromq.ZMQ;
import java.util.StringTokenizer;

public class KepSRFLAG {

    public static ZMQ.Context context;
    public static ZMQ.Socket server;
    public static int sizetab=150;

    public static void init() {
        // Prepare our context and socket
        context = ZMQ.context(1);
        server = context.socket(ZMQ.REP);
        server.bind("tcp://*:5555");
        System.err.println("connected to Simulink:");
    }

    public static void send(int flag) {        
        System.err.print("KepSRFlag send begin, value="+flag+"\n");
        String update = String.format("%d\u0000",flag);
        server.send(update.getBytes(),0); 
        System.err.printf("KepSRFlag send ok\n");
       }

    public static void senddata(double[] anArray) {        
        //double[] anArray;
        String data;

        System.err.print("KepSRFlag send data begin\n");
        // allocates memory
        /*
        anArray = new double[sizetab];
        for (int i=0;i< sizetab;i++) {
            anArray[i]=i;
        } 
        */ 
        data=String.valueOf(anArray[0]);
        for (int i=1;i< sizetab;i++) {
            data=data+" "+String.valueOf(anArray[i]);
        }
        data=data+"\u0000";
        server.send(data.getBytes(),0); 
        System.err.printf("KepSRFlag send data ok\n");
       }

     public static int recv() {
       int flag=0;
       System.err.printf("KepSRFlag recv begin\n");
       String string = new String(server.recv(0)).trim();
       StringTokenizer sscanf = new StringTokenizer(string, " ");
       String t = sscanf.nextToken();
       flag = Integer.valueOf(t);
       System.err.printf("KepSRFlag recv ok, value="+flag+"\n");
       return flag;
     }

    public static double[] recvdata() {
       double[] anArray;

       System.err.printf("KepSRFlag recv data begin\n");
       // allocates memory
        anArray = new double[sizetab+1];

       String string = new String(server.recv(0)).trim();
       StringTokenizer sscanf = new StringTokenizer(string, " ");
       String t;
       System.err.printf("KepSRFlag recv data ok, value=");
       for (int i=0;i< sizetab+1;i++) {
            t = sscanf.nextToken();
            anArray[i]=Double.valueOf(t);
            System.err.printf(anArray[i]+" ");
        }  
       System.err.printf("\n");
       return anArray; 
     }
     public static void close() {
        server.close();
        context.term();
        System.err.println("close connection to Simulink");
     }

/*
    public static void main(String[] args) {
       int flag=0;
       init();
       flag=recv();
       flag=2;
       send(flag);
       close();
     } 
*/
}


