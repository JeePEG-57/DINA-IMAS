package eu.itm.pcsdialog;
import java.io.*;
import ptolemy.actor.TypedAtomicActor;
import ptolemy.actor.TypedIOPort;
import ptolemy.data.Token;
import ptolemy.data.DoubleToken;
import ptolemy.data.StringToken;
import ptolemy.kernel.CompositeEntity;
import java.util.Iterator;
import java.util.List;
import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;
import ptolemy.actor.Actor;
import ptolemy.actor.CompositeActor;
import ptolemy.actor.Director;
import ptolemy.data.IntToken;
import ptolemy.data.BooleanToken;
import ptolemy.data.ArrayToken;
import ptolemy.data.expr.Parameter;
import ptolemy.domains.sdf.kernel.*;
import ptolemy.kernel.util.Nameable;
import ptolemy.kernel.util.NamedObj;
import ptolemy.data.type.RecordType;
import ptolemy.data.RecordToken;

import ptolemy.actor.CompositeActor;
import ptolemy.actor.Director;
import ptolemy.actor.IOPort;

import ptolemy.actor.TypedCompositeActor;
import ptolemy.actor.TypedIOPort;

import ptolemy.data.expr.Variable;
import ptolemy.data.type.BaseType;
import ptolemy.data.type.Type;
import ptolemy.data.type.TypeLattice;
import ptolemy.data.type.ArrayType;
import ptolemy.graph.CPO;
import ptolemy.graph.Inequality;
import ptolemy.graph.InequalityTerm;

import ptolemy.kernel.ComponentEntity;
import ptolemy.kernel.ComponentRelation;
import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.Port;
import ptolemy.kernel.Relation;

import ptolemy.kernel.util.Attribute;
import ptolemy.kernel.util.StringAttribute;
import ptolemy.kernel.util.Location;
import ptolemy.kernel.util.SingletonAttribute;
import ptolemy.kernel.util.Settable.Visibility;
import ptolemy.kernel.util.Settable;
//for hash table .......
import java.util.Hashtable;
import java.util.Dictionary;
import java.util.Enumeration;

import java.net.MalformedURLException;


public class pcsdialog extends TypedAtomicActor {

    /* Ports */
    public TypedIOPort input;
    public TypedIOPort output;

    public int KepFlag;
    public int SimFlag;

    public pcsdialog(CompositeEntity container, String name)
	throws IllegalActionException, NameDuplicationException {
	super(container, name);
	
    input = new TypedIOPort(this,"input",true,false);
    new SingletonAttribute(input, "_showName");
    input.setTypeEquals(new ArrayType( BaseType.DOUBLE ));

    output = new TypedIOPort(this,"output",false, true);
    new SingletonAttribute(output, "_showName");
    output.setTypeEquals(new ArrayType( BaseType.DOUBLE ));


	_attachText("_iconDescription", "<svg>\n"
		    + "<rect x=\"-20\" y=\"-20\" " + "width=\"40\" height=\"40\" "
		    + "style=\"fill:white\"/>\n" + "<text x=\"-13\" y=\"-5\" "
		    + "style=\"font-size:18\">\n" + "+ \n" + "</text>\n"
		    + "<text x=\"-13\" y=\"7\" " + "style=\"font-size:18\">\n"
		    + "_ \n" + "</text>\n" + "</svg>\n");
    }
    
    public void initialize() throws IllegalActionException {
        super.initialize();
        KepFlag=0;
        SimFlag=0;
        KepSRFLAG.init();
    }

    public void fire() throws IllegalActionException {
	super.fire();
        System.err.println("enter pcsdialog");
        //Token inoutvalue = input.get(0);

        KepFlag+=1;
        SimFlag=KepSRFLAG.recv();
        if (SimFlag == -1) {
          System.err.println("End of Simulink");
          //sortir
        }
        if (SimFlag != KepFlag) {
          System.err.println("Kepler communication Error, KepFlag:"+KepFlag+", SimFlag:"+SimFlag);
          //sortir
        }
        KepSRFLAG.send(KepFlag);

        //data communications
        double[] anArrayin;
        double[] anArrayout;
        int sizetab=150;
        anArrayin=KepSRFLAG.recvdata(); 
        /*
        anArrayout=new double[sizetab];
        for (int i=0;i< sizetab;i++) {
            anArrayout[i]=0.0;
        }
        anArrayout[0]=1.0;
        */
        anArrayout=arrayTokenToDoubleArray((ArrayToken) input.get(0));
        KepSRFLAG.senddata(anArrayout);     
        System.err.println("size of input pcsdialog "+anArrayin.length);
        String strAnArrayin= utilArraytoString(anArrayin);
        output.send(0,new ArrayToken(strAnArrayin));
	//output.send(0,inoutvalue);
        System.err.println("exit pcsdialog");       
    }
    public void wrapup() throws IllegalActionException {
        super.wrapup();

        KepFlag=-1;
        SimFlag=KepSRFLAG.recv();
        KepSRFLAG.send(KepFlag);
        System.err.println("wraping up");
        KepSRFLAG.close();
        
    }

    public static double[] arrayTokenToDoubleArray(ArrayToken arrT) {
        int n=arrT.length();
        double[] result= new double[n];
        for (int i=0; i<n; i++)
             result[i] = ( (DoubleToken)arrT.getElement(i) ).doubleValue();
       return result;
    }
    public static String utilArraytoString(double[] dArr) {
        String dStr = "{";
        int dsize = dArr.length;
        for (int dimCount = 0; dimCount < dsize-1; dimCount++)
               dStr += dArr[dimCount] + ", ";
        dStr += dArr[dsize-1] + "}";
        return dStr;
    }

}
